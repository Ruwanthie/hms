-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2018 at 08:29 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE `admin_user` (
  `userid` int(10) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `username` varchar(500) NOT NULL,
  `password` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_user`
--

INSERT INTO `admin_user` (`userid`, `firstname`, `lastname`, `username`, `password`) VALUES
(1, 'admin ', 'admin ', 'dasperera2@gmail.com ', '81dc9bdb52d04dc20036dbd8313ed055');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(10) NOT NULL,
  `name` varchar(250) NOT NULL,
  `surname` varchar(250) NOT NULL,
  `address` varchar(100) NOT NULL,
  `arrival_date` date NOT NULL,
  `departure_date` date NOT NULL,
  `nic` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(250) NOT NULL,
  `adults` int(10) NOT NULL,
  `kids` int(10) NOT NULL,
  `roomtype` varchar(250) NOT NULL,
  `roomno` int(10) NOT NULL,
  `payment_date` date DEFAULT NULL,
  `amount` float NOT NULL DEFAULT '0',
  `pay_status` varchar(500) NOT NULL DEFAULT '"Not Paid"'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `name`, `surname`, `address`, `arrival_date`, `departure_date`, `nic`, `phone`, `email`, `adults`, `kids`, `roomtype`, `roomno`, `payment_date`, `amount`, `pay_status`) VALUES
(1, 'Deepani', 'Perera', '315/1 kandaliyadha paluwa', '2018-12-12', '2018-12-24', '948000075v', '764805857', 'isara.didulantha123@gmail.com', 2, 1, 'Executive Suite', 1, '2018-12-12', 240000, 'Not Paid'),
(2, 'Dasuni', 'Perera', '315/1 kandaliyadha paluwa', '2018-12-21', '2018-12-31', '948000075v', '764805857', 'did.perera123@gmail.com', 2, 1, 'Executive Suite ', 1, NULL, 0, '\"Not Paid\"'),
(3, 'Isara', 'Didulantha', '175/B Soorigama Kadawatha', '2019-01-08', '2019-01-23', '976131504V', '0775405857', 'isara.didulantha123@gmail.com', 2, 1, 'Executive Suite ', 1, NULL, 0, '\"Not Paid\"'),
(4, 'Hasali', 'Dimanthie', 'Colombo', '2019-01-02', '2019-01-13', '932510465V', '0778191993', 'hsd@yahoo.com', 2, 0, 'Executive Suite ', 1, NULL, 0, '\"Not Paid\"'),
(5, 'Sajeewa', 'Upashantha', 'Gampaha', '2019-01-16', '2018-12-20', '681550712v', '0117208292', 'sajee@ymail.com', 2, 0, 'Executive Suite ', 1, NULL, 0, '\"Not Paid\"'),
(6, 'Upali', 'Perera', '175/B Soorigama Kadawatha', '2018-12-17', '2018-12-25', '976131504V', '764805857', 'did.perera123@gmail.com', 2, 1, 'Executive Suite ', 1, NULL, 0, '\"Not Paid\"');

-- --------------------------------------------------------

--
-- Table structure for table `login_info`
--

CREATE TABLE `login_info` (
  `login_info_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `status` varchar(250) NOT NULL,
  `ip` varchar(500) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_info`
--

INSERT INTO `login_info` (`login_info_id`, `username`, `status`, `ip`, `date`) VALUES
(1, 'admin', 'Logged In', '::1', '2018-12-10 20:38:06'),
(2, 'admin', 'Logged Out', '::1', '2018-12-10 20:38:06'),
(3, 'admin', 'Logged In', '::1', '2018-12-10 20:38:06'),
(4, 'admin', 'Logged In', '::1', '2018-12-10 20:38:06'),
(5, 'admin', 'Logged In', '::1', '2018-12-10 20:38:06'),
(6, 'admin', 'Logged In', '::1', '2018-12-10 20:38:06'),
(7, 'admin', 'Logged In', '::1', '2018-12-10 20:38:06'),
(8, 'admin', 'Logged Out', '::1', '2018-12-10 20:38:09'),
(9, 'admin', 'Logged In', '::1', '2018-12-10 20:38:16'),
(10, 'admin', 'Logged In', '::1', '2018-12-11 06:23:42'),
(11, 'admin', 'Logged Out', '::1', '2018-12-11 09:40:19'),
(12, 'admin', 'Logged In', '::1', '2018-12-11 09:43:39'),
(13, 'admin', 'Logged In', '::1', '2018-12-11 11:17:20');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `roomid` int(10) NOT NULL,
  `location` varchar(500) NOT NULL,
  `roomtype` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`roomid`, `location`, `roomtype`) VALUES
(1, 'Basement - Left Side', 'Executive Suite '),
(2, 'Basement - Left Side', 'Executive Suite '),
(3, 'Basement - Left Side', 'Executive Suite '),
(4, 'Basement - Left Side', 'Executive Suite '),
(5, 'Basement - Right Side', 'Double Deluxe Room'),
(6, '01st Floor - Left Side', 'Single Deluxe Room'),
(7, '01st Floor - Right Side', 'Double Deluxe Room');

-- --------------------------------------------------------

--
-- Table structure for table `room_allocaion`
--

CREATE TABLE `room_allocaion` (
  `allocation_id` int(11) NOT NULL,
  `booking_id` int(10) NOT NULL,
  `room_no` int(10) NOT NULL,
  `roomtype` varchar(250) NOT NULL,
  `status` varchar(200) NOT NULL,
  `book_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room_allocaion`
--

INSERT INTO `room_allocaion` (`allocation_id`, `booking_id`, `room_no`, `roomtype`, `status`, `book_date`) VALUES
(2, 1, 4, 'Executive Suite ', 'Reserved', '2018-12-12'),
(3, 0, 5, 'Double Deluxe Room', 'Available', NULL),
(4, 0, 6, 'Single Deluxe Room', 'Available', NULL),
(5, 0, 7, 'Double Deluxe Room', 'Available', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `room_category`
--

CREATE TABLE `room_category` (
  `category_id` int(10) NOT NULL,
  `category` varchar(500) NOT NULL,
  `rate` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room_category`
--

INSERT INTO `room_category` (`category_id`, `category`, `rate`) VALUES
(1, 'Executive Suite', 20000),
(2, 'Double Deluxe Room', 5000),
(3, 'Single Deluxe Room', 4000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_user`
--
ALTER TABLE `admin_user`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `login_info`
--
ALTER TABLE `login_info`
  ADD PRIMARY KEY (`login_info_id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`roomid`);

--
-- Indexes for table `room_allocaion`
--
ALTER TABLE `room_allocaion`
  ADD PRIMARY KEY (`allocation_id`);

--
-- Indexes for table `room_category`
--
ALTER TABLE `room_category`
  ADD PRIMARY KEY (`category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_user`
--
ALTER TABLE `admin_user`
  MODIFY `userid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `login_info`
--
ALTER TABLE `login_info`
  MODIFY `login_info_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `roomid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `room_allocaion`
--
ALTER TABLE `room_allocaion`
  MODIFY `allocation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `room_category`
--
ALTER TABLE `room_category`
  MODIFY `category_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
