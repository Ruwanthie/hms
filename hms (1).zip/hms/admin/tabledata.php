<?php
require('include/connection.php');

	


  if (mysqli_connect_errno()) {

      printf("Connect failed: %s\n", mysqli_connect_error());

      exit();

  }


  $booking_id = $_POST['booking_id'];
  $room_no = $_POST['room_no'];
  $room_type = $_POST['room_type'];
  $status = $_POST['status'];
  $book_date = $_POST['book_date'];
 

  if (mysqli_query($db, "INSERT into  room_allocaion  (booking_id,room_no,roomtype,status,book_date) values ('$booking_id','$room_no','$room_type','$status','$book_date')") === TRUE) {

    echo("GOOD");

  }

  else
    echo "Failed";


	?>