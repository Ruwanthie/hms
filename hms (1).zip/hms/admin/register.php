<?php
// START SESSION
session_start();

require('include/connection.php');


?>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>Register</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body class="bg-dark">
<?php

    if (isset($_POST['Register']) ) {



        $first_name = mysqli_real_escape_string($db,$_POST['first_name']);
        $last_name = mysqli_real_escape_string($db,$_POST['last_name']);
        $username = mysqli_real_escape_string($db,$_POST['username']);
        $password = mysqli_real_escape_string($db,$_POST['pwd']);
        $md5password=md5($password);
        
        


        if(empty($_POST['first_name']))
        {
            $error[] = "First name field is required";
        }
        if(empty($_POST['last_name']))
        {
            $error[] = "Last name field is required";
        }
        if(empty($_POST['username']))
        {
            $error[] = "Username field is required";
        }
        if(empty($_POST['pwd']))
        {
            $error[] = "Password field is required";
        }
        if($_POST['pwd'] != $_POST['c_pwd'] )
        {
            $error[] = "Password field and confrim password field is not matched";
        }
          
        $sql = "INSERT INTO admin_user(firstname,lastname,username,password) VALUES ('$first_name','$last_name','$username','$md5password')";

        $result = mysqli_query($db, $sql);
        //Update status
        if ($result) {
            $smsg = "User Registration Successful. ";
        } else {
            $fmsg = "User Registration Failed. ";
        }

    }
    ?>
  <div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header">Register an Account</div>
      <div class="card-body">
        <form method="POST">
           <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"><i class="icon fa fa-ban"></i> <?php echo $fmsg; ?>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> </div><?php } ?>
                <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"><i class="icon fa fa-check"></i><?php echo $smsg; ?><span class="glyphicon glyphicon-thumbs-up"></span>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div><?php } ?>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="first_name">First name</label>
                <input class="form-control" name="first_name" id="first_name" type="text" aria-describedby="nameHelp" placeholder="Enter first name">
              </div>
              <div class="col-md-6">
                <label for="last_name">Last name</label>
                <input class="form-control" name="last_name" id="last_name" type="text" aria-describedby="nameHelp" placeholder="Enter last name">
              </div>
            </div>
          </div>
          <div class="form-group">
            <label for="username">Username</label>
            <input class="form-control" name="username" id="username" type="text" aria-describedby="nameHelp" placeholder="Enter username">
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="pwd">Password</label>
                <input class="form-control" name="pwd" id="pwd" type="password" placeholder="Password">
              </div>
              <div class="col-md-6">
                <label for="c_pwd">Confirm password</label>
                <input class="form-control" name="c_pwd" id="c_pwd" type="password" placeholder="Confirm password">
              </div>
            </div>
          </div>
          <input class="btn btn-primary btn-block" type="submit"  id="Register" name="Register" value="Register"/>
        </form>
        <div class="text-center">
          <a class="d-block small mt-3" href="login.php">Login Page</a>
          <a class="d-block small" href="forgot-password.html">Forgot Password?</a>
        </div>
      </div>
    </div>
  </div>
  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
</body>

</html>
