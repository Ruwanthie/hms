<!DOCTYPE html>
<html>
<head>

</head>
<body>


<table class="w3-table w3-striped w3-bordered w3-border w3-hoverable w3-white">
    <thead>

    
    <th>Reserved Room No.</th>
    </thead>
    <tbody>
    <?php
    include('include/connection.php');
    header('Access-Control-Allow-Origin: *');

    $q = $_GET['q'];

    $query=mysqli_query($db,"SELECT * FROM room_allocaion WHERE booking_id = '".$q."'");
   
    while($row=mysqli_fetch_array($query)){
        ?>
        <tr>
           
            <td><?php echo $row['room_no']; ?></td>
           
    

        </tr>


        <?php
    }

    ?>
    </tbody>
</table>
  

</body>
</html>