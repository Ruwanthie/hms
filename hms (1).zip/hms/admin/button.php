
<!-- Delete -->
<div class="modal fade" id="delete_room<?php echo $row['allocation_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel"></h4></center>
            </div>
            <div class="modal-body">
                <?php
                $del=mysqli_query($db,"select * from room_allocaion where allocation_id='".$row['allocation_id']."'");
                $drow=mysqli_fetch_array($del);
                ?>
                <div class="container-fluid">
                    <p><b><center>Do You Really Want to Delete This  ?</center></b></p>
                    
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <a href="delete_room.php?id=<?php echo $row['allocation_id']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
            </div>

        </div>
    </div>
</div>
<!-- /.modal -->

<!-- Delete -->
<div class="modal fade" id="delete_user<?php echo $row['userid']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel"></h4></center>
            </div>
            <div class="modal-body">
                <?php
                $del=mysqli_query($db,"select * from admin_user where userid='".$row['userid']."'");
                $drow=mysqli_fetch_array($del);
                ?>
                <div class="container-fluid">
                    <p><b><center>Do You Really Want to Delete This  ?</center></b></p>
                    
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <a href="delete_user.php?id=<?php echo $row['userid']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
            </div>

        </div>
    </div>
</div>
<!-- /.modal -->


<!-- Delete -->
<div class="modal fade" id="delete_booking<?php echo $row['booking_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel"></h4></center>
            </div>
            <div class="modal-body">
                <?php
                $del=mysqli_query($db,"select * from booking where booking_id='".$row['booking_id']."'");
                $drow=mysqli_fetch_array($del);
                ?>
                <div class="container-fluid">
                    <p><b><center>Do You Really Want to Delete This  ?</center></b></p>
                    
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <a href="delete_booking.php?id=<?php echo $row['booking_id']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
            </div>

        </div>
    </div>
</div>
<!-- /.modal -->


<!-- Delete -->
<div class="modal fade" id="delete_formb<?php echo $row['form_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <center><h4 class="modal-title" id="myModalLabel"></h4></center>
            </div>
            <div class="modal-body">
                <?php
                $del=mysqli_query($db,"select * from form_c where form_id='".$row['form_id']."'");
                $drow=mysqli_fetch_array($del);
                ?>
                <div class="container-fluid">
                    <p><b><center>Do You Really Want to Delete This  ?</center></b></p>
                    
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancel</button>
                <a href="delete_formb.php?id=<?php echo $row['form_id']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Delete</a>
            </div>

        </div>
    </div>
</div>
<!-- /.modal -->
