<?php
$server ="localhost";
$serveruser="root";
$serverpassword ="";
$databasename ="hms";
$db= mysqli_connect($server,$serveruser,$serverpassword,$databasename);

//Checking the connection
if(mysqli_connect_error()){
    die("Database connection failed ".mysqli_connect_error());
}

?>