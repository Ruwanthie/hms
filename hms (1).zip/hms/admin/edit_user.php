<?php
// START SESSION
session_start();
require('include/connection.php');
$id = $_GET['id'];

?>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>COST 32172</title>
  <!-- Bootstrap core CSS-->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin.css" rel="stylesheet">
   <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
     <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/css/bootstrap-datepicker.css" rel="stylesheet">
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.5.0/js/bootstrap-datepicker.js"></script>

</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="index.php">COST 32172</a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" href="index.php">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>

         <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Example Pages">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseExamplePages2" data-parent="#exampleAccordion2">
            <i class="fa fa-fw fa-diamond"></i>
            <span class="nav-link-text">Reservation</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseExamplePages2">
            <li>
                <a class="nav-link" href="booking.php">
                <i class="fa fa-fw fa-link"></i>
                <span class="nav-link-text">Add info</span>
                </a>
            </li>

            <li>
              <a class="nav-link" href="manage_bookings.php">
                <i class="fa fa-fw fa-link"></i>
                <span class="nav-link-text">View info</span>
              </a>
            </li>
           
            
          </ul>
        </li>
       
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Management of Users">
          <a class="nav-link" href="manage_payments.php">
            <i class="fa fa-fw fa-money"></i>
            <span class="nav-link-text">Payment</span>
          </a>
        </li>

         <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Example Pages">
          <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseExamplePages4" data-parent="#exampleAccordion4">
            <i class="fa fa-fw fa-home"></i>
            <span class="nav-link-text">Room</span>
          </a>
          <ul class="sidenav-second-level collapse" id="collapseExamplePages4">
            <li>
                <a class="nav-link" href="room.php">
                <i class="fa fa-fw fa-link"></i>
                <span class="nav-link-text">Add Room</span>
                </a>
            </li>

            <li>
              <a class="nav-link" href="room_category.php">
                <i class="fa fa-fw fa-link"></i>
                <span class="nav-link-text">Add Category</span>
              </a>
            </li>
           
           <li>
              <a class="nav-link" href="manage_rooms.php">
                <i class="fa fa-fw fa-link"></i>
                <span class="nav-link-text">View Info</span>
              </a>
            </li>
            
          </ul>
        </li>

        <li class="nav-item active" data-toggle="tooltip" data-placement="right" title="Management of Users">
          <a class="nav-link" href="manage_users.php">
            <i class="fa fa-fw fa-user"></i>
            <span class="nav-link-text">User Management</span>
          </a>
        </li>
        
      </ul>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle mr-lg-2" id="messagesDropdown" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-fw fa-envelope"></i>
            <span class="d-lg-none">Messages
              <span class="badge badge-pill badge-primary">12 New</span>
            </span>
            <span class="indicator text-primary d-none d-lg-block">
              <i class="fa fa-fw fa-circle"></i>
            </span>
          </a>
          <div class="dropdown-menu" aria-labelledby="messagesDropdown">
            <h6 class="dropdown-header">New Messages:</h6>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">
              <strong>David Miller</strong>
              <span class="small float-right text-muted">11:21 AM</span>
              <div class="dropdown-message small">Hey there! This new version of SB Admin is pretty awesome! These messages clip off when they reach the end of the box so they don't overflow over to the sides!</div>
            </a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">
              <strong>Jane Smith</strong>
              <span class="small float-right text-muted">11:21 AM</span>
              <div class="dropdown-message small">I was wondering if you could meet for an appointment at 3:00 instead of 4:00. Thanks!</div>
            </a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">
              <strong>John Doe</strong>
              <span class="small float-right text-muted">11:21 AM</span>
              <div class="dropdown-message small">I've sent the final files over to you for review. When you're able to sign off of them let me know and we can discuss distribution.</div>
            </a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item small" href="#">View all messages</a>
          </div>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle mr-lg-2" id="alertsDropdown" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-fw fa-bell"></i>
            <span class="d-lg-none">Alerts
              <span class="badge badge-pill badge-warning">6 New</span>
            </span>
            <span class="indicator text-warning d-none d-lg-block">
              <i class="fa fa-fw fa-circle"></i>
            </span>
          </a>
          <div class="dropdown-menu" aria-labelledby="alertsDropdown">
            <h6 class="dropdown-header">New Alerts:</h6>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">
              <span class="text-success">
                <strong>
                  <i class="fa fa-long-arrow-up fa-fw"></i>Status Update</strong>
              </span>
              <span class="small float-right text-muted">11:21 AM</span>
              <div class="dropdown-message small">This is an automated server response message. All systems are online.</div>
            </a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">
              <span class="text-danger">
                <strong>
                  <i class="fa fa-long-arrow-down fa-fw"></i>Status Update</strong>
              </span>
              <span class="small float-right text-muted">11:21 AM</span>
              <div class="dropdown-message small">This is an automated server response message. All systems are online.</div>
            </a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#">
              <span class="text-success">
                <strong>
                  <i class="fa fa-long-arrow-up fa-fw"></i>Status Update</strong>
              </span>
              <span class="small float-right text-muted">11:21 AM</span>
              <div class="dropdown-message small">This is an automated server response message. All systems are online.</div>
            </a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item small" href="#">View all alerts</a>
          </div>
        </li>
       <li class="nav-item">
       <a class="dropdown-item" href="#">
              <span class="text-success">
            <span>Welcome, <strong><?=$_SESSION['sess_user'];?></strong></span></span>
         </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i>Logout</a>
        </li>
      </ul>
    </div>
  </nav>
  <div class="content-wrapper" style="background-color: #FFFF80;">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Dashboard</a>
        </li>
        <li class="breadcrumb-item"><a href="manage_users.php">User Management</a></li>
        <li class="breadcrumb-item active">User Information</li>
      </ol>
      <h3> &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;
            &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;
            &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;  &nbsp;
        User Information</h3>
      
      <hr>
     
      <div class="container" style="align:center;" >
      
    

      <div class="col-lg-10">
            
        <?php

require('include/connection.php');
    if (isset($_POST['save_btn']) ) {

        $id = $_GET['id'];
        $firstname= mysqli_real_escape_string($db,$_POST['firstname']);
        $lastname= mysqli_real_escape_string($db,$_POST['lastname']);
        $username= mysqli_real_escape_string($db,$_POST['username']);
        $password = mysqli_real_escape_string($db,$_POST['pwd']);
        $md5password=md5($password);
       

        if(empty($_POST['firstname']))
        {
            $error[] = "First Name is required";
        }
        if(empty($_POST['lastname']))
        {
            $error[] = "Last Name is required";
        }
        if(empty($_POST['username']))
        {
            $error[] = "Username is required";
        }
        if(empty($_POST['pwd']))
        {
            $error[] = "Password is required";
        }
        if($_POST['pwd'] != $_POST['c_pwd'] )
        {
            $error[] = "Password field and confrim password field is not matched";
        }
        
       

        $sql = "UPDATE admin_user SET firstname='$firstname',lastname='$lastname',username='$username',password='$md5password' WHERE userid='$id'";

        $result = mysqli_query($db, $sql);
        if ($result) {
            $smsg = "Updated Successfully. ";
        } else {
            $fmsg = "Failed to update.";
        }
    }
    ?>
       
    <?php
            include('include/connection.php');
            //getting id from url
            $id = $_GET['id'];

            //selecting data associated with this particular id
            $sql = mysqli_query($db, "SELECT * FROM admin_user WHERE userid=$id");

            while($row = mysqli_fetch_array($sql))
            {
                $firstname = $row['firstname'];
                $lastname = $row['lastname'];
                $username= $row['username'];
              }
    ?>


         <form method="post"  style="width: 800px;margin: 85px ;">
           <?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"><i class="icon fa fa-ban"></i> <?php echo $fmsg; ?>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> </div><?php } ?>
                <?php if(isset($smsg)){ ?><div class="alert alert-success" role="alert"><i class="icon fa fa-check"></i><?php echo $smsg; ?><span class="glyphicon glyphicon-thumbs-up"></span>
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div><?php } ?>
         
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label><b>User ID : <?php echo $id; ?></b></label>
              </div>
        
            </div>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="firstname">First Name</label>
                <input class="date-own form-control" id="firstname" name="firstname" type="text" aria-describedby="nameHelp" placeholder="Enter First Name" value="<?php echo $firstname; ?> " >
              </div>
              <div class="col-md-6">
                <label for="lastname">Last Name</label>
                <input class="form-control" id="lastname" name="lastname" type="text" aria-describedby="nameHelp" placeholder="Enter Last Name" value="<?php echo $lastname; ?> "   >
              </div>
            </div>
          </div>
          <div class="form-group">
            <label for="username">Username</label>
            <input class="form-control" id="username" name="username" type="text" aria-describedby="nameHelp" placeholder="Enter Username" value="<?php echo $username; ?> ">
          </div>
           
           <div class="form-group">
            <div class="form-row">
            
              <div class="col-md-6">
                 <label for="pwd">Password</label>
                <input class="form-control" name="pwd" id="pwd" type="password" placeholder="Password">
              </div>
               <div class="col-md-6">
                <label for="c_pwd">Confirm password</label>
                <input class="form-control" name="c_pwd" id="c_pwd" type="password" placeholder="Confirm password">
              </div>
          
          </div>
          <br/>
            <button type="submit" class="btn btn-primary" name="save_btn" id="save_btn">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SAVE <span class="glyphicon glyphicon-floppy-disk"></span>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</button>
             
          
        </form>
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

  
    </div>
    </div>
    </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>COST 32172 Project @2018</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.php">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <!-- Toggle between fixed and static navbar-->
    <script>
    $('#toggleNavPosition').click(function() {
      $('body').toggleClass('fixed-nav');
      $('nav').toggleClass('fixed-top static-top');
    });

    </script>
    <!-- Toggle between dark and light navbar-->
    <script>
    $('#toggleNavColor').click(function() {
      $('nav').toggleClass('navbar-dark navbar-light');
      $('nav').toggleClass('bg-dark bg-light');
      $('body').toggleClass('bg-dark bg-light');
    });

    </script>
  </div>
</body>

