<?php
include('include/connection.php');
$id=$_GET['id'];
mysqli_query($db,"delete from room_allocaion where allocation_id='$id'");
header("location:manage_rooms.php?page=1");

?>
