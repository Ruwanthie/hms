<?php
include('include/connection.php');
$id=$_GET['id'];
mysqli_query($db,"delete from booking where booking_id='$id'");
header("location:manage_bookings.php?page=1");

?>