<?php
include('include/connection.php');
$id=$_GET['id'];
mysqli_query($db,"delete from admin_user where userid='$id'");
header("location:manage_users.php?page=1");

?>
