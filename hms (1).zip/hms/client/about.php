<?php
// START SESSION
session_start();

require('includes/connection.php');

?>

<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="icon" href="image/favicon.png" type="image/png">
        <title>Club Bentota</title>
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="vendors/linericon/style.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="vendors/bootstrap-datepicker/bootstrap-datetimepicker.min.css">
        <link rel="stylesheet" href="vendors/nice-select/css/nice-select.css">
        <link rel="stylesheet" href="vendors/owl-carousel/owl.carousel.min.css">
        <!-- main css -->
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/responsive.css">
    </head>
    <body>
        <!--================Header Area =================-->
        <header class="header_area">
            <div class="container">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <a class="navbar-brand logo_h" href="index.html"><img src="image/Logo.png" alt=""></a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse offset" id="navbarSupportedContent">
                        <ul class="nav navbar-nav menu_nav ml-auto">
                            <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li> 
                            <li class="nav-item active"><a class="nav-link" href="about.php">About us</a></li>
                            <li class="nav-item"><a class="nav-link" href="accomodation.php">Accomodation</a></li>
                            <li class="nav-item"><a class="nav-link" href="gallery.php">Gallery</a></li>
                            <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                        </ul>
                    </div> 
                </nav>
            </div>
        </header>
        <!--================Header Area =================-->
        
        <!--================Breadcrumb Area =================-->
        <section class="breadcrumb_area">
            <div class="overlay bg-parallax" data-stellar-ratio="0.8" data-stellar-vertical-offset="0" data-background=""></div>
            <div class="container">
                <div class="page-cover text-center">
                    <h2 class="page-cover-tittle">About Us</h2>
                    <ol class="breadcrumb">
                        <li><a href="index.php

                            ">Home</a></li>
                        <li class="active">About</li>
                    </ol>
                </div>
            </div>
        </section>
        <!--================Breadcrumb Area =================-->
        
        <!--================ About History Area  =================-->
        <section class="about_history_area section_gap">

            <div class="container">
                <div class="row">
                    <div class="col-md-6 d_flex align-items-center">
                        <div class="about_content ">
                            <h2 class="title title_color">About Us</h2>
                            <p>Water sports, sand and surf in your mind? Then Club Bentota is the place to be. Surrounded by the ocean and the Bentota River, the hotel offers you an array of facilities and leisure activities that can help you forget your daily routine and enjoy your vacation thoroughly. From wellness to jet skiing, and from delicious cuisine to a long and lazy dip in the pool, Club Bentota is a venue that you can sit back and relax to your heart's content.<br><br>
                            Club Bentota is located towards the South West coast of Sri Lanka surrounded by the Bentota River and the Indian Ocean. Populated with palms as well as tropical trees, Bentota is about 60km away from Colombo and about 100km away from the Bandaranaike International Airport in Katunayake. The hotel's ideal location provides guests with the rare opportunity of having two beaches facing the beach and the river.</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <img class="img-fluid" src="image/about_bg.jpg" alt="img">
                    </div>
                </div>
            <section class="blog_area single-post-area">
              <div class="container">
            <div class="row">
            <div class="col-lg-8 posts-list">

            <div class="single-post row">

              <div class="col-lg-12">
                <div class="quotes">
                   Bentota being the water sports capital of Sri Lanka, Club Bentota offers you the privilege of using their comprehensive water sports centre which is well equipped with jet skis, water skis, surf boards, speed boats and many more. There are professionals to help you with instructions. Further to this, cruises can be organized along the Bentota River or maybe enjoy a nature trail in one of the adjoining jungles. With time in hand, guests can make a visit to the historical city of Galle and witness the magnificent Galle Fort that still stands in all its glory.                                      
                </div>
                <div class="row">
                    <div class="col-6">
                        <img class="img-fluid" src="image/blog/blog-1.jpg" alt="">
                    </div>
                    <div class="col-6">
                        <img class="img-fluid" src="image/blog/blog-2.jpg" alt="">
                    </div>  
                    <div class="col-lg-12 mt-25">
                        <p>
                            Club Bentota offers you complete wellness facilities allowing you to pamper yourself through herbal baths and full body massages of your choice. There is also a steam sauna at the hotel. You can be sure to enjoy delicious meals be it vegetarian or non-vegetarian. There are various children's menus prepared to their liking. Daily dinner served at Club Bentota is according to a special theme while the seating is spacious offering beautiful views. You can also enjoy romantic candle-lit meals in secluded locations or even order from the in-room dining menu.

                         </p>
                        <p>
                           Other hotel facilities include a swimming pool, shopping arcade, internet cafe, travel desk, wireless internet access, currency exchange, multi lingual staff, porter services, animators, parking with 24 hour security, a children play area, a water sports centre, outdoor and indoor sports activities and an open air theatre.
        
                        </p>  

                    </div> 


                </div>


            </div>
        </div>
    </div>
     <div class="col-lg-4">
                        <div class="blog_right_sidebar">
                           
                         
                           
                            <aside class="single_sidebar_widget ads_widget">
                                <a href="#"><img class="img-fluid" src="image/blog/cat-post-1.jpg" alt=""></a>
                                <div class="br"></div>
                            </aside>

                            <aside class="single_sidebar_widget ads_widget">
                                <a href="#"><img class="img-fluid" src="image/blog/feature-img1.jpg" alt=""></a>
                                <div class="br"></div>
                            </aside>

                            <aside class="single_sidebar_widget ads_widget">
                                <a href="#"><img class="img-fluid" src="image/blog/m-blog-4.jpg" alt=""></a>
                                <div class="br"></div>
                            </aside>

                            <aside class="single_sidebar_widget ads_widget">
                                <a href="#"><img class="img-fluid" src="image/blog/m-blog-1.jpg" alt=""></a>
                                <div class="br"></div>
                            </aside>
                           
                          
                           
                        </div>
                    </div>
                </div>
            </div>
</div>

            </div>

              
                </div>
            </div>
        </section>
            </div>
            

        </section>
        <!--================ About History Area  =================-->
        
        <!--================ Facilities Area  =================-->
        <section class="facilities_area section_gap">
            <div class="overlay bg-parallax" data-stellar-ratio="0.8" data-stellar-vertical-offset="0" data-background="">  
            </div>
            <div class="container">
                <div class="section_title text-center">
                    <h2 class="title_w">Club Bentota Facilities</h2>
                    <p>Who are in extremely love with eco friendly system.</p>
                </div>
                <div class="row mb_30">
                    <div class="col-lg-4 col-md-6">
                        <div class="facilities_item">
                            <h4 class="sec_h4"><i class="lnr lnr-dinner"></i>Restaurant</h4>
                            <p>With vaulted ceilings and vintage décor, the Garden Restaurant is spacious enough to accommodate 250 people and is a pleasant environment to dine in. </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="facilities_item">
                            <h4 class="sec_h4"><i class="lnr lnr-bicycle"></i>Sports Centre</h4>
                            <p>Club Bentota offers you the privilege of using their comprehensive water sports centre which is well equipped with jet skis, water skis, surf boards, speed boats and many more. </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="facilities_item">
                            <h4 class="sec_h4"><i class="lnr lnr-shirt"></i>Swimming Pool</h4>
                            <p>As if the waves of the Indian Ocean and the Bentota River surrounding us are not enough, Club Bentota also has an extremely large swimming pool open to the guests of the hotel.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="facilities_item">
                            <h4 class="sec_h4"><i class="lnr lnr-car"></i>Rent a Car</h4>
                            <p>Taxi Cab Service is conducted by English Speaking Chauffeur Guides who are friendly, punctual and put your safety first above everything else. Rent a car now and enjoy a hassle free ride.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="facilities_item">
                            <h4 class="sec_h4"><i class="lnr lnr-construction"></i>Spa</h4>
                            <p>CocoSpa has developed a comprehensive selection of spa treatments using nature’s gifts only: exotic essential oils, fragrances, spices, herbs, flowers, and fruits.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="facilities_item">
                            <h4 class="sec_h4"><i class="lnr lnr-coffee-cup"></i>Bar</h4>
                            <p>Immerse yourself in the stylish setting of the Bar where you can relax and enjoy laidback drinks as you reminisce over the day's events. Perfect spot to chill-out and unwind.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================ Facilities Area  =================-->
        
        
        <!--================ Testimonial Area  =================-->
        <section class="testimonial_area section_gap">
            <div class="container">
                <div class="section_title text-center">
                    <h2 class="title_color">Testimonial from our Clients</h2>
                   
                </div>
                <div class="testimonial_slider owl-carousel">
                    <div class="media testimonial_item">
                        <img class="rounded-circle" src="image/testtimonial-1.jpg" alt="">
                        <div class="media-body">
                            <p>This was the first time in Sri Lanka, we stayed in Colombo in Pegasus resort for two days and moved to Club Bentota for another 3 nights, truly an awesome experience with pristine location and the lagoon kind of feeling.</p>
                            <a href="#"><h4 class="sec_h4">Fanny Spencer</h4></a>
                            <div class="star">
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star"></i></a>
                            </div>
                        </div>
                    </div>    
                    <div class="media testimonial_item">
                        <img class="rounded-circle" src="image/testtimonial-2.jpg" alt="">
                        <div class="media-body">
                            <p>Had such a super 3 days at Club Bentota, you can drive directly from Colombo airport, it's about 2 hour drive roughly. No point staying at Colombo, it's crowded, expensive and a city life, there nothing there for a tourist. </p>
                            <a href="#"><h4 class="sec_h4">Jeevikkas</h4></a>
                            <div class="star">
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star-half-o"></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="media testimonial_item">
                        <img class="rounded-circle" src="image/c5.jpg" alt="">
                        <div class="media-body">
                            <p>We gotta take a quick boat ride to the reception from main land. Large hotel so the guests are spread out. Staff was friendly and attentive. Room was smaller than expected and comfortable. Not sound proof. It wasn't too private. </p>
                            <a href="#"><h4 class="sec_h4">Ash J</h4></a>
                            <div class="star">
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star-half-o"></i></a>
                            </div>
                        </div>
                    </div>    
                    <div class="media testimonial_item">
                        <img class="rounded-circle" src="image/c6.jpg" alt="">
                        <div class="media-body">
                            <p>We only stayed one night at Club Bentota and unfortunately arrived later than expected so we had no time to enjoy the pool/beach area. We checked in and went to our room which was beautiful.  But the Buffet is very weak. </p>
                            <a href="#"><h4 class="sec_h4">Sheonah</h4></a>
                            <div class="star">
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star"></i></a>
                                <a href="#"><i class="fa fa-star-half-o"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================ Testimonial Area  =================-->
        
         <!--================ start footer Area  =================-->   
        <footer class="footer-area section_gap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3  col-md-6 col-sm-6">
                        <div class="single-footer-widget">
                            <h6 class="footer_title">About Club Bentota</h6>
                            <p>Club Bentota is located towards the South West coast of Sri Lanka surrounded by the Bentota River and the Indian Ocean. </p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-footer-widget">
                            <h6 class="footer_title">Navigation Links</h6>
                            <div class="row">
                                <div class="col-4">
                                    <ul class="list_style">
                                        <li><a href="index.php">Home</a></li>
                                        <li><a href="about.php">About Us</a></li>
                                        <li><a href="accomodation.php">Accomodation</a></li>
                                    </ul>
                                </div>
                                <div class="col-4">
                                    <ul class="list_style">
                                        <li><a href="gallery.php">Gallery</a></li>
                                        <li><a href="contact.php">Contact</a></li>
                                    </ul>
                                </div>                                      
                            </div>                          
                        </div>
                    </div>                          
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-footer-widget">
                            <h6 class="footer_title">Newsletter</h6>
                            <p>Get the latest updates, events about Club Bentota. Please subscribe to our newsletter.</p>       
                            <div id="mc_embed_signup">
                                <form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="subscribe_form relative">
                                    <div class="input-group d-flex flex-row">
                                        <input name="EMAIL" placeholder="Email Address" onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address '" required="" type="email">
                                        <button class="btn sub-btn"><span class="lnr lnr-location"></span></button>     
                                    </div>                                  
                                    <div class="mt-10 info"></div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-footer-widget instafeed">
                            <h6 class="footer_title">InstaFeed</h6>
                            <ul class="list_style instafeed d-flex flex-wrap">
                                <li><img src="image/instagram/Image-01.jpg" alt=""></li>
                                <li><img src="image/instagram/Image-02.jpg" alt=""></li>
                                <li><img src="image/instagram/Image-03.jpg" alt=""></li>
                                <li><img src="image/instagram/Image-04.jpg" alt=""></li>
                                <li><img src="image/instagram/Image-05.jpg" alt=""></li>
                                <li><img src="image/instagram/Image-06.jpg" alt=""></li>
                                <li><img src="image/instagram/Image-07.jpg" alt=""></li>
                                <li><img src="image/instagram/Image-08.jpg" alt=""></li>
                            </ul>
                        </div>
                    </div>                      
                </div>
                <div class="border_line"></div>
                <div class="row footer-bottom d-flex justify-content-between align-items-center">
                    <p class="col-lg-8 col-sm-12 footer-text m-0">
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This peoject is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="" target="_blank">COST 32172</a>
</p>
                    <div class="col-lg-4 col-sm-12 footer-social">
                        <a href="https://www.facebook.com"><i class="fa fa-facebook"></i></a>
                        <a href="https://twitter.com"><i class="fa fa-twitter"></i></a>
                        <a href="https://www.instagram.com"><i class="fa fa-instagram"></i></a>
                        <a href="https://www.linkedin.com"><i class="fa fa-linkedin-square"></i></a>
                    </div>
                </div>
            </div>
        </footer>
        <!--================ End footer Area  =================-->
        
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="js/jquery-3.2.1.min.js"></script>
        <script src="js/popper.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
        <script src="js/jquery.ajaxchimp.min.js"></script>
        <script src="vendors/bootstrap-datepicker/bootstrap-datetimepicker.min.js"></script>
        <script src="vendors/nice-select/js/jquery.nice-select.js"></script>
        <script src="js/mail-script.js"></script>
        <script src="js/stellar.js"></script>
        <script src="vendors/lightbox/simpleLightbox.min.js"></script>
        <script src="js/custom.js"></script>
    </body>
</html>