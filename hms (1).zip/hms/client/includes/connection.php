<?php
$server ="localhost";
$serveruser="root";
$serverpassword ="";
$databasename ="hms";
$db= mysqli_connect($server,$serveruser,$serverpassword,$databasename);
?>