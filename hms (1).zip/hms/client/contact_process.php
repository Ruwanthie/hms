 <?php 


                        if(isset($_POST['Mail'])){
                
                      /*  $name=$_POST['name']; // Get Name value from HTML Form
                        $subject=$_POST['subject'];  // Get Mobile No
                        $email=$_POST['email'];  // Get Email Value
                        $message=$_POST['message']; // Get Message Value
*/
                        require 'PHPMailer/PHPMailerAutoload.php';

                        $mail = new PHPMailer;
                        //$mail->SMTPDebug = 3;                               // Enable verbose debug output

                        $mail->isSMTP();                                      // Set mailer to use SMTP
                        $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
                        $mail->SMTPAuth = true;                               // Enable SMTP authentication
                        $mail->Username = 'dasperera2@gmail.com';                 // SMTP username
                        $mail->Password = '1026dasuni';                           // SMTP password
                        $mail->Port = 587;                                    // TCP port to connect to

                        $mail->From = 'dasperera2@gmail.com';
                        $mail->FromName = 'Dasuni Perera';
                        $mail->addAddress('dasperera24@gmail.com'); 
                       /* $mail->AddCC ($email);              // Name is optional
*/
                        $mail->isHTML(true);                                  // Set email format to HTML

                        $mail->Subject = 'Inquiry';
                        $mail->Body    = ' <b>Customer Inquiry</b> From Customer';
                       

                        if(!$mail->send()) {
                         
                            $msg = 'Mailer Error: ' . $mail->ErrorInfo;
                           
                        } else {
                         
                            $msg =  'Message has been sent';
                        }
                       }                   
                                
                    ?>